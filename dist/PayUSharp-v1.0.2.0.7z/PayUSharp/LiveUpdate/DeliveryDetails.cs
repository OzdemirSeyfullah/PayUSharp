using System;
using System.Collections.Generic;

namespace PayU.LiveUpdate
{
    public class DeliveryDetails: PayU.Base.DeliveryDetails
    {
    }

}

