using System;
using System.Collections.Generic;

namespace PayU.LiveUpdate
{
    public class BillingDetails: PayU.Base.BillingDetails
    {
    }

}

