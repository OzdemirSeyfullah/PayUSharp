﻿namespace PayU.AutomaticLiveUpdate
{
    public class BillingDetails: PayU.Base.BillingDetails
    {
    }
}