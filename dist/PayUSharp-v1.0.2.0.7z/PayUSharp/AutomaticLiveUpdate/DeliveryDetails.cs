using System;

namespace PayU.AutomaticLiveUpdate
{
    public class DeliveryDetails: PayU.Base.DeliveryDetails
    {
    }
}

